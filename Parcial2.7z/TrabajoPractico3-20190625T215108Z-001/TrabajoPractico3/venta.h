#ifndef venta_H_INCLUDED
#define venta_H_INCLUDED
typedef struct
{
    int id;
    int idCliente;
    char codigo[128];
    int cantidad;

}Venta;

Venta* venta_new();
Venta* venta_newParametros(char* idStr,char* idClienteStr,char* codigoStr,char* CantStr);
void venta_delete(Venta * this);

//hacer funcions para string tmb
int venta_setId(Venta* this,int id);
int venta_getId(Venta* this,int* id);

int venta_setIdCliente(Venta* this,int idCliente);
int venta_getIdCliente(Venta* this,int* idCliente);

int venta_setCodigo(Venta* this,char* codigo);
int venta_getCodigo(Venta* this,char* codigo);

int venta_setCant(Venta* this,int cantidad);
int venta_getCant(Venta* this,int* cantidad);


#endif // venta_H_INCLUDED

