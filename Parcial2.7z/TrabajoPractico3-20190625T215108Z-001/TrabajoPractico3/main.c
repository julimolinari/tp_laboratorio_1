#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"
#include "parser.h"
#include "funciones.h"
/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/
//carga fscanf - descarga fprintf---- alta pedir datos, verificar y construir un emp en memoria
//llamamos al constructor, si se dvalida con el add incorporoo al arraylist
//modificacion- obtener al empleado-- hacef funcion para encontrar emplaso x id-- findById, te paso array y id, me encontras al empleado
//uso la misma para la baja, pido id dar de baja findByid(rcorre y ve si coincide el id)devuelve el indice con retorno! != -1
//listar
//ordenar . el arraylist sabe ordenarse. le pasamos que(el arralist) y bajo que CRITERIO-recibe dos empleados y devuelve un numero
//funcion sort(lepaso el nombre de la funcion criterio), puntero a funcion criterio, implementa una forma de ordenar
//guardar -en modo binario..pedir al arraaylist el primero entre 0 y el len un for, tengo el primer puntero a archivo
//y guardo no el puntero si no al empeado.. con ese puntero se lo paso a write con * con size of empleado
//cuando leo del puntero l guardo en un puntero empleado
int main()
{
    int option = 0;
    int flag= 0;
    LinkedList* listaEntregas = ll_newLinkedList();


    do
    {
        getIntInRange(&option,"\n1)Cargar Entregas: \n"
                      "2)INFORME: \n"
                      "11)Salir\n","ERROR\n",1,11,3);
        switch(option)
        {
        case 1:
            if(flag == 0)
            {
                if(!controller_loadFromText("data.csv",listaEntregas))
                {
                    controller_ListEntregas(listaEntregas);
                    flag=1;
                }
                else
                {
                    printf("No se cargo el archivo\n-------");
                }
            }
            else
                printf("\nYa se cargo este archivo\n-------");

            break;
            case 2:
            if(flag == 1)
            {
                if(!controller_saveAsText("Informes.csv",listaEntregas))//if(!controller_Informe(listaEntregas))
                {
                    //controller_ListEntregas(listaEntregas);
                    //controller_saveAsText("Informes.csv",listaEntregas);
                    flag=1;
                }
                else
                {
                    printf("No se cargo el archivo\n-------");
                }
            }
            else
                printf("\nYa se cargo este archivo\n-------");

            break;

        }

    }
    while(option != 11);
    return 0;
}
