#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Employee.h"
#include "funciones.h"


/** \brief Crea un nuevo empleado
 *
 * \return Empleado nuevo
 *
 */
Entregas* entregas_new(void)
{
    return (Entregas*) malloc(sizeof(Entregas));
}

/** \brief Crea empleados cargandole los parametros
 *
 * \param idStr char*
 * \param nombreStr char*
 * \param horasTrabajadasStr char*
 * \param sueldoStr char*
 * \return Empleado nuevo
 *
 */
Entregas* entregas_newParametros(char* idStr,char* tipoStr,char* cantidadStr,char* importeStr)
{
    Entregas* retorno = NULL;
    Entregas* pAuxEntregas;
    if(idStr != NULL && tipoStr != NULL && cantidadStr != NULL && importeStr != NULL)
    {
       pAuxEntregas = entregas_new();
        if(pAuxEntregas != NULL)
        {
            if(!entregas_setTipo(pAuxEntregas,tipoStr) &&
               !entregas_setCantidad(pAuxEntregas,atoi(cantidadStr)) &&
               !entregas_setImporte(pAuxEntregas,atof(importeStr)) &&
               !entregas_setId(pAuxEntregas,atoi(idStr)))
            {
                retorno =pAuxEntregas;
            }else
            {
                entregas_delete(pAuxEntregas);
            }
        }
    }
    return retorno;
}

/** \brief Elimina a un empleado pasado por parametro
 *
 * \return void
 *
 */
void entregas_delete(Entregas * this)
{
    if(this != NULL)
    {
        free(this);

    }
}

/** \brief Asigna id en el empleado indicado
 *
 * \param this Entregas*
 * \param id int
 * \return int
 *
 */
int entregas_setId(Entregas* this,int id)
{
    int retorno = -1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene id del empleado indicado
 *
 * \param this Entregas*
 * \param id int*
 * \return int
 *
 */
int entregas_getId(Entregas* this,int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}

/** \brief Asigna nombre en el empleado indicado
 *
 * \param this Entregas*
 * \param nombre char*
 * \return int
 *
 */
int entregas_setTipo(Entregas* this,char* tipo)
{
    int retorno = -1;
    if(this != NULL && tipo != NULL)
    {
        strcpy(this->tipo,tipo);
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene nombre del empleado indicado
 *
 * \param this Entregas*
 * \param nombre char*
 * \return int
 *
 */
int entregas_getTipo(Entregas* this,char* tipo)
{
    int retorno = -1;
    if(this != NULL && tipo != NULL)
    {
        strcpy(tipo,this->tipo);
        retorno = 0;
    }
    return retorno;
}


/** \brief Compara el nombre de los empleados
 *
 * \param pEmpleado void*
 * \param pEmpleado2 void*
 * \return int
 *

int entregas_compararPorNombre(void*pEmpleado,void*pEmpleado2)
{
    int diff;
    if(pEmpleado2 != NULL && pEmpleado != NULL)
    {
        diff = strcmp(((Entregas*)pEmpleado)->nombre,((Entregas*)pEmpleado2)->nombre);

    }

    return diff;
}
 */
int entregas_setCantidad(Entregas* this,int cantidad)
{
    int retorno = -1;
    if(this != NULL && cantidad >= 0)
    {
        this->cantidad = cantidad;
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene id del empleado indicado
 *
 * \param this Entregas*
 * \param id int*
 * \return int
 *
 */
int entregas_getCantidad(Entregas* this,int* cantidad)
{
    int retorno = -1;
    if(this != NULL && cantidad != NULL)
    {
        *cantidad = this->cantidad;
        retorno = 0;
    }
    return retorno;
}


int entregas_setImporte(Entregas* this,float importe)
{
    int retorno = -1;
    if(this != NULL && importe >= 0)
    {
        this->importe = importe;
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene id del empleado indicado
 *
 * \param this Entregas*
 * \param id int*
 * \return int
 *
 */
int entregas_getImporte(Entregas* this,float* importe)
{
    int retorno = -1;
    if(this != NULL && importe != NULL)
    {
        *importe = this->importe;
        retorno = 0;
    }
    return retorno;
}
