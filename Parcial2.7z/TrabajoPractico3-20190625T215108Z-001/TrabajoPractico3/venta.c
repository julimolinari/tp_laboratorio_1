#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Employee.h"
#include "funciones.h"
#include "venta.h"


/** \brief Crea un nuevo empleado
 *
 * \return Empleado nuevo
 *
 */
Venta* venta_new(void)
{
    return (Venta*) malloc(sizeof(Venta));
}

/** \brief Crea empleados cargandole los parametros
 *
 * \param idStr char*
 * \param nombreStr char*
 * \param horasTrabajadasStr char*
 * \param sueldoStr char*
 * \return Empleado nuevo
 *
 */
Venta* venta_newParametros(char* idStr,char* idClienteStr,char* codigoStr,char* CantStr)
{
    Venta* retorno = NULL;
    Venta* pAuxVenta;
    if(idStr != NULL && idClienteStr != NULL && codigoStr != NULL && CantStr != NULL)
    {
        pAuxVenta = venta_new();
        if(pAuxVenta != NULL)
        {
            if(!venta_setIdCliente(pAuxVenta,atoi(idClienteStr)) &&
               !venta_setCodigo(pAuxVenta,codigoStr) &&
               !venta_setCant(pAuxVenta,atoi(CantStr)) &&
               !venta_setId(pAuxVenta,atoi(idStr)))
            {
                retorno = pAuxVenta;
            }else
            {
                venta_delete(pAuxVenta);
            }
        }
    }
    return retorno;
}

/** \brief Elimina a un empleado pasado por parametro
 *
 * \return void
 *
 */
void venta_delete(Venta * this)
{
    if(this != NULL)
    {
        free(this);

    }
}

/** \brief Asigna id en el empleado indicado
 *
 * \param this Venta*
 * \param id int
 * \return int
 *
 */
int venta_setId(Venta* this,int id)
{
    int retorno = -1;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene id del empleado indicado
 *
 * \param this Venta*
 * \param id int*
 * \return int
 *
 */
int venta_getId(Venta* this,int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;
}


int venta_setCodigo(Venta* this,char* codigo)
{
    int retorno = -1;
    if(this != NULL && codigo != NULL)
    {
        strcpy(this->codigo,codigo);
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene nombre del empleado indicado
 *
 * \param this Venta*
 * \param nombre char*
 * \return int
 *
 */
int venta_getCodigo(Venta* this,char* codigo)
{
    int retorno = -1;
    if(this != NULL && codigo != NULL)
    {
        strcpy(codigo,this->codigo);
        retorno = 0;
    }
    return retorno;
}




/** \brief Obtiene id del empleado indicado
 *
 * \param this Venta*
 * \param id int*
 * \return int
 *
 */
int venta_getIdCliente(Venta* this,int* idCliente)
{
    int retorno = -1;
    if(this != NULL && idCliente != NULL)
    {
        *idCliente = this->idCliente;
        retorno = 0;
    }
    return retorno;
}


int venta_setIdCliente(Venta* this,int idCliente)
{
    int retorno = -1;
    if(this != NULL && idCliente >= 0)
    {
        this->idCliente = idCliente;
        retorno = 0;
    }
    return retorno;
}

/** \brief Obtiene id del empleado indicado
 *
 * \param this Venta*
 * \param id int*
 * \return int
 *
 */
int venta_getCant(Venta* this,int* cantidad)
{
    int retorno = -1;
    if(this != NULL && cantidad != NULL)
    {
        *cantidad = this->cantidad;
        retorno = 0;
    }
    return retorno;
}

int venta_setCant(Venta* this,int cantidad)
{
    int retorno = -1;
    if(this != NULL && cantidad >= 0)
    {
        this->cantidad = cantidad;
        retorno = 0;
    }
    return retorno;
}
