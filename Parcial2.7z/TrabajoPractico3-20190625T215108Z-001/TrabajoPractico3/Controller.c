#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "parser.h"
#include "funciones.h"
#include "Controller.h"
#include "Employee.h"

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEntregas LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListEntregas)
{
    int retorno = -1;
    FILE* pFile = NULL;
    int len = 0;

    if(path != NULL && pArrayListEntregas != NULL)
    {
        pFile = fopen (path, "rw");
        if(pFile != NULL)
        {
            if (parser_EntregasFromText(pFile,pArrayListEntregas)==0)
            {
                retorno=0;
                len = ll_len(pArrayListEntregas);
                printf("\nRegistros Cargados: %d%s",len,"\n-------");
            }
        }
        fclose (pFile);
    }
    return retorno;
}



int controller_ListEntregas(LinkedList* pArrayListEntregas)
{
    int retorno = -1;
    int i;
    int len;
    char bufferTipo[500];
    int bufferCantidad;
    float bufferImporte;
    int bufferId;

    len = ll_len(pArrayListEntregas);
    Entregas* pEntregas;
    if(pArrayListEntregas != NULL)
    {
        for(i=0; i<len; i++)
        {
            pEntregas = ll_get(pArrayListEntregas,i);
            entregas_getTipo(pEntregas,bufferTipo);
            entregas_getId(pEntregas,&bufferId);
            entregas_getCantidad(pEntregas,&bufferCantidad);
            entregas_getImporte(pEntregas,&bufferImporte);

            printf("\nID: %d\nTipo: %s\nCantidad: %d\nImporte: %f\n-------",
                   bufferId,bufferTipo,bufferCantidad,bufferImporte);
        }
    }

    return retorno;
}
/*

int controller_Informe(LinkedList* pArrayListEntregas)
{
    int retorno = -1;
    int i;
    int len;
    char bufferTipo[500];
    int bufferCantidad;
    int auxBuffer=0;
    float bufferImporte;
    //int bufferId;
    float total;
    float promedioTotal;
    int contGold;
    int contRegular;
    int contPlus;
    int auxPromedio;

    len = ll_len(pArrayListEntregas);
    Entregas* pEntregas;
    if(pArrayListEntregas != NULL)
    {
        for(i=0; i<len; i++)
        {
            pEntregas = ll_get(pArrayListEntregas,i);
            entregas_getTipo(pEntregas,bufferTipo);
            entregas_getCantidad(pEntregas,&bufferCantidad);
            entregas_getImporte(pEntregas,&bufferImporte);
            total = bufferImporte + total;
            auxBuffer = bufferCantidad + auxBuffer;
            if(strcasecmp(bufferTipo,"GOLD")==0)
            {
                contGold++;
            }else if(strcasecmp(bufferTipo,"REGULAR")==0)
            {
                contRegular++;
            }else if(strcasecmp(bufferTipo,"PLUS")==0)
            {
                contPlus++;
            }
        }
        auxPromedio = auxBuffer / len;
        promedioTotal = total / len;
        printf("\nCantidad de entregas:%d\n-------",len);
         printf("\nCantidad de entregas:\nGOLD %d\nREGULAR %d\nPLUS %d\n-------",
                   contGold,contRegular,contPlus);
        printf("\nCantidad de bultos entregados:%d\n-------",auxBuffer);
        printf("\nPromedio de bultos x entrega:%d\n-------",auxPromedio);
        printf("\nImporte promedio x entrega:%.2f\n-------",promedioTotal);
        retorno=0;
    }

    return retorno;
}

*/
int controller_saveAsText(char* path, LinkedList* pArrayListEntregas)
{
    int retorno = -1;
    int i;
    int len;
    char bufferTipo[500];
    int bufferCantidad;
    int auxBuffer=0;
    float bufferImporte;
    //int bufferId;
    float total;
    float promedioTotal;
    int contGold;
    int contRegular;
    int contPlus;
    int auxPromedio;

    Entregas *pEntregas=NULL;
    FILE *pFileBkp = NULL;

    if(path != NULL && pArrayListEntregas != NULL)
    {
        pFileBkp = fopen(path,"wb");
        if(pFileBkp != NULL)
        {
            len = ll_len(pArrayListEntregas);
             for(i=0; i<len; i++)
        {
            pEntregas = ll_get(pArrayListEntregas,i);
            entregas_getTipo(pEntregas,bufferTipo);
            entregas_getCantidad(pEntregas,&bufferCantidad);
            entregas_getImporte(pEntregas,&bufferImporte);
            total = bufferImporte + total;
            auxBuffer = bufferCantidad + auxBuffer;
            if(strcasecmp(bufferTipo,"GOLD")==0)
            {
                contGold++;
            }else if(strcasecmp(bufferTipo,"REGULAR")==0)
            {
                contRegular++;
            }else if(strcasecmp(bufferTipo,"PLUS")==0)
            {
                contPlus++;
            }
        }
        auxPromedio = auxBuffer / len;
        promedioTotal = total / len;

        fprintf(pFileBkp,"%s %d\n","\n-Cantidad de entregas:",len);
        fprintf(pFileBkp,"%s %s %d %s %d %s %d\n","\n-Cantidad de entregas:","GOLD", contGold,"REGULAR",contRegular,"PLUS",contPlus);
        fprintf(pFileBkp,"%s %d\n","\n-Cantidad de bultos entregados:",auxBuffer);
        fprintf(pFileBkp,"%s %d\n","\n-Promedio de bultos x entrega:",auxPromedio);
        fprintf(pFileBkp,"%s %.2f\n","\n-Importe promedio x entrega:",promedioTotal);

        retorno=0;
    }

        }
        retorno = 0;
        fclose(pFileBkp);

        return retorno;
    }


