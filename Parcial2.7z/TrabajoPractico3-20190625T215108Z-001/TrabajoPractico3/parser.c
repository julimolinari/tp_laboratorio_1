#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EntregasFromText(FILE* pFile, LinkedList* pArrayListEntregas)
{
    int retorno = -1;
    char bufferId[500];
    char bufferTipo[500];
    char bufferCantidad[500];
    char bufferImporte[500];
    int r=0;

    Entregas *pAuxEntregas;

    if(pFile!= NULL && pArrayListEntregas != NULL)
    {
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",bufferId,bufferTipo,bufferCantidad,bufferImporte);

            if(r==0)
            {
                r++;
                continue;
            }

            pAuxEntregas = entregas_newParametros(bufferId,bufferTipo,bufferCantidad,bufferImporte);
            if(pAuxEntregas != NULL)
            {
                ll_add(pArrayListEntregas,pAuxEntregas);
                retorno = 0;
            }
        }
    }
    return retorno;
}


/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *

int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{
//primero generar el binario, el que escribe, no puntero si no lo apuntado por el(file write)
    int retorno = -1;
    Employee auxEmpleado;
    Employee* pEmpleado;

    if(pFile != NULL && pArrayListEmployee != NULL)
    {
            while(!feof(pFile))
            {

                    pEmpleado = employee_new();
                fread(&auxEmpleado,sizeof(Employee),1,pFile);
                if( !employee_setId(pEmpleado,auxEmpleado.id) &&
                    !employee_setNombre(pEmpleado,auxEmpleado.nombre) &&
                    !employee_setApellido(pEmpleado,auxEmpleado.apellido) &&
                    !employee_setDni(pEmpleado,auxEmpleado.dni))
                {
                     ll_add(pArrayListEmployee,pEmpleado);
                }
                else
                {
                    employee_delete(pEmpleado);
                }
                }

                retorno = 0;

    }
    fclose(pFile);
    return  retorno;
}
*/
